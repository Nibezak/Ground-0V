"""
Integration tests for testing interactions between components.
""" 