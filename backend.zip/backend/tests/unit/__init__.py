"""
Unit tests for individual components of the Manim code generation system.
""" 