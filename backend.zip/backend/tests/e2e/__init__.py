"""
End-to-end tests for testing the complete workflow from prompt to video generation.
""" 