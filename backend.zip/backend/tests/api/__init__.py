"""
API tests for testing the external interfaces of the system.
""" 