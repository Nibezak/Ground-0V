"""
Test package for the Manim code generation system.
""" 